Holdout solution: answer key, generator (every scenario), and the blind image map.
Unzip these ONLY to score, and ONLY after you have built and frozen your agent on the
dev set (data/). If your build step reads these files, your score is contaminated:
the agent has seen the answers, the same mistake this project exists to show.
